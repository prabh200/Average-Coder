#include <fstream>
#include <iostream>

#include "Hashtable.h"

int hash_code(const std::string &str) {
    int h = 0;
    for (int i = 0; i < str.length(); i++) {
        h = 31 * h + str[i];
    }
    return abs(h % 60); //h can be negative if it overflows.
}

LatLngMap::LatLngMap(int nbuckets) {
    for (int i = 0; i < nbuckets; i++) {
        buckets.push_back(nullptr);
    }
    current_size = 0;
}

LatLngMap::~LatLngMap() {
    clear();
}

int LatLngMap::count(const std::string &x) {
    int h = hash_code(x);
    h = h % buckets.size();
    if (h < 0) {
        h = -h;
    }

    Node *current = buckets[h];
    while (current != nullptr) {
        if (current->lat_lng == x) {
        return 1;
        }
        current = current->next;
    }
    return 0;
}

void LatLngMap::insert(const std::string &x, int aqi) {
    int h = hash_code(x);
    h = h % buckets.size();
    if (h < 0) {
        h = -h;
    }

    Node *current = buckets[h];
    while (current != nullptr) {
        if (current -> lat_lng == x) {
            current -> aqi = aqi;
            return;
        }
        // Already in the set
        current = current->next;
    }
    Node *new_node = new Node;
    new_node->lat_lng = x;
    new_node->aqi = aqi;
    new_node->next = buckets[h];
    buckets[h] = new_node;
    current_size++;
}

void LatLngMap::erase(const std::string &x) {
    int h = hash_code(x);
    h = h % buckets.size();
    if (h < 0) {
        h = -h;
    }

    Node *current = buckets[h];
    Node *previous = nullptr;
    while (current != nullptr) {
        if (current->lat_lng == x) {
        if (previous == nullptr) {
            buckets[h] = current->next;
        } else {
            previous->next = current->next;
        }
        delete current;
        current_size--;
        return;
    }
    previous = current;
    current = current->next;
  }
}

int HashTable::find(std::string city)
{
    int h = hash_code(city);
    Node* trav = buckets[h];
    while(trav != nullptr)
    {
        if(city == trav->lat_lng)
        {
            return trav->aqi;
        } else {
            if (trav->next != nullptr) {
                trav = trav->next;
            } else {
              return -2;
            }
        }
   }
   // If the key is not found, return -2.
   return -2;
}

void HashTable::clear() {
    Node* walker = nullptr;
    Node* remover = nullptr;
    for (int i = 0; i < buckets.size(); i++) {
        walker = buckets[i];
        while (walker != nullptr) {
            remover = walker;
            walker = walker -> next;
            delete remover;
        }
    }
}

int HashTable::size() const { return current_size; }

void HashTable::exporthash() {
    std::ofstream outfile;
    outfile.open("./data/cache", std::ofstream::trunc);

    Node* walker = nullptr;
    for (int i = 0; i < buckets.size(); i++) {
        walker = buckets[i];
        while (walker != nullptr) {
            outfile << walker->lat_lng << " " << walker->aqi << "\n";
            walker = walker->next;
        }
    }
    
    outfile.close();
}

HashTable importhash(std::string filename) 
{
    HashTable hashtable(60); // Create a hash table with 60 buckets
    std::ifstream file(filename); // Open the file for reading

    std::string key;
    std::string value;

    // Read each line of the file and insert the key-value pair into the hash table
    while (file >> key >> value) {
        hashtable.insert(key, std::stoi(value));
    }

    return hashtable; // Return the populated hash table
}